package com.sunbeam.Service;

import java.util.List;

import com.sunbeam.entities.Categories;

public interface CatService {

  List<Categories> getAllCat();

}
