package com.sunbeam;

public interface CustomerDao {

	Customer findByEmail(String email);
}
